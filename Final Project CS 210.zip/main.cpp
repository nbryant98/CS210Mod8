/* Nathanael Bryant*/
/* Module 7 Project*/
/* Grocery Store Item Tracker*/


#include <iostream>
#include <fstream>
#include <string>
#include <map>
#include <limits>
#include <iomanip>

using namespace std;

class CornerGrocerTracker {
private:
    std::map<std::string, int> itemFrequencies;
    const std::string INPUT_FILE = "CS210_Project_Three_Input_File.txt";
    const std::string OUTPUT_FILE = "frequency.dat";

    
    bool LoadData() {
        std::ifstream inputFile(INPUT_FILE);
        if (!inputFile.is_open()) {
            std::cerr << "Error: Could not open input file " << INPUT_FILE;
            return false;
        }

        std::string item;
        // Reading items and storing their count
        while (inputFile >> item) {
            itemFrequencies[item]++;
        }

        inputFile.close();
        return true;
    }

   
    void BackupData() {
        std::ofstream outputFile(OUTPUT_FILE);
        if (!outputFile.is_open()) {
            std::cerr << "Could not open backup file " << OUTPUT_FILE;
            return;
        }

        // Iterating and storing the count
        for (const auto& pair : itemFrequencies) {
            outputFile << pair.first << " " << pair.second << "\n";
        }

        outputFile.close();
    }

    //display menu for user
    void DisplayMenu() {
        std::cout << "Corner Grocer Item Tracker\n";
        std::cout << "1. Look up a specific item's quantity\n";
        std::cout << "2. Print a list of all item frequencies\n";
        std::cout << "3. Print a histogram number of items\n";
        std::cout << "4. Exit the program\n";
        std::cout << "Enter a number (1-4): ";
    }

    
    void FrequencyLookup() {
        std::string itemToFind;
        std::cout << "Enter the item name to look up: ";
        std::cin >> itemToFind;

        if (itemFrequencies.count(itemToFind)) {
            std::cout << itemToFind << " was purchased "
                << itemFrequencies[itemToFind] << " time(s).\n";
        }
        else {
            std::cout << itemToFind << " was purchased 0 time(s).\n";
        }
    }

    
    void PrintFrequencies() {
        std::cout << "Item Quantity" << endl;

        const int columnWidth = 15;
        for (const auto& pair : itemFrequencies) {
            std::cout << std::left << std::setw(columnWidth) << pair.first
                << pair.second << "\n";
        }
  
    }

   
    void PrintHistogram() {
        std::cout << "Item Quantity" << endl;

        const int columnWidth = 15;
        for (const auto& pair : itemFrequencies) {
            std::cout << std::left << std::setw(columnWidth) << pair.first;

            // Print a '*' for each item amount
            for (int i = 0; i < pair.second; ++i) {
                std::cout << "*";
            }
            std::cout << "\n";
        }
    }

public:
    
    CornerGrocerTracker() {
        std::cout << "Initializing Corner Grocer Item Tracker...\n";
        if (LoadData()) {
            BackupData();
            std::cout << "Data loaded successfully and backed up to " << OUTPUT_FILE << ".\n";
        }
        else {
            std::cout << "Program cannot proceed without input data.\n";
        }
    }

    
    void Run() {
        int choice = 0;

        // Only run the menu if the data has loaded
        if (itemFrequencies.empty()) {
            return;
        }

        do {
            DisplayMenu();
            // Input validation loop
            while (!(std::cin >> choice) || choice < 1 || choice > 4) {
                std::cout << "Invalid input. Please enter a number between 1 and 4: ";
                std::cin.clear();
                std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            }

            switch (choice) {
            case 1:
                FrequencyLookup(); // Menu Option One
                break;
            case 2:
                PrintFrequencies(); // Menu Option Two
                break;
            case 3:
                PrintHistogram(); // Menu Option Three
                break;
            case 4:
                std::cout << "\nExiting the Item Tracker. Goodbye!\n"; // Menu Option Four
                break;
            }

        } while (choice != 4);
    }
};


int main() {
  
    CornerGrocerTracker tracker;

    tracker.Run();

    return 0;
}